const express = require('express');
let router = express.Router();
const rp = require('request-promise');
const cheerio = ('cheerio');
// const $ = ('cheerio');


let jsonxml = require('jsontoxml');


router.post('/',(req,res)=>{
    let url= req.body.url;
    let title,images;
    let result = { title : "", images : ""};
    rp(url)
    .then(function(html){
      console.log(html)
      let $ = cheerio.load(html);
      title = $('title').text();
      result.title = title;
      images= $('img').attr('src');
      result.images = images;
    let xml = jsonxml({
      node:'text content',
      result
    });
    return res.send(result);
    })
  
    .catch(function(err){
  
          return err
      
        });
     
 })

module.exports = router;